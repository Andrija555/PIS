@extends('layouts.app')

@section('title', 'Uredi Zadatak')

@section('content')

	<div class="row">
		<div class="col-sm-12">
			<h1>Uredi Zadatakk</h1>
			{!! Form::model($task, ['route' => ['task.update', $task->id], 'method' => 'PUT']) !!}
				@component('components.taskForm')
				@endcomponent
			{!! Form::close() !!}
		</div>
	</div>

@endsection